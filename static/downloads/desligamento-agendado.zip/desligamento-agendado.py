import os
import sys
import time
import re
import unicodedata
import subprocess
import platform

# ── ANSI Colors ───────────────────────────────────────────────────────────────
RED     = "\033[91m"
YELLOW  = "\033[93m"
GREEN   = "\033[92m"
CYAN    = "\033[96m"
MAGENTA = "\033[95m"
WHITE   = "\033[97m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
RESET   = "\033[0m"

# Largura interna da caixa (colunas visíveis entre ║ e ║)
W = 62

# ── Largura visual precisa ────────────────────────────────────────────────────

# Emojis/símbolos que terminals modernos renderizam com 2 colunas,
# mas unicodedata.east_asian_width não detecta corretamente como Wide.
_WIDE_EXTRA = {
    # Relógios analógicos 🕐-🕛 e 🕜-🕧
    *range(0x1F550, 0x1F568),
    # Rostos / emojis comuns do plano BMP que aparecem com 2 cols
    0x231A, 0x231B,  # ⌚ ⌛
    0x23E9, 0x23EA, 0x23EB, 0x23EC, 0x23ED, 0x23EE, 0x23EF,
    0x23F0, 0x23F3,  # ⏰ ⏳
    0x25AA, 0x25AB, 0x25B6, 0x25C0,
    0x25FB, 0x25FC, 0x25FD, 0x25FE,
    0x2600, 0x2601, 0x2602, 0x2603, 0x2604,
    0x260E, 0x2611, 0x2614, 0x2615,
    0x2618, 0x261D, 0x2620, 0x2622, 0x2623,
    0x2626, 0x262A, 0x262E, 0x262F,
    0x2638, 0x2639, 0x263A,
    0x2640, 0x2642,
    *range(0x2648, 0x2654),  # signos
    0x265F, 0x2660, 0x2663, 0x2665, 0x2666, 0x2668,
    0x267B, 0x267E, 0x267F,
    0x2692, 0x2693, 0x2694, 0x2695, 0x2696, 0x2697,
    0x2699, 0x269B, 0x269C,
    0x26A0, 0x26A1, 0x26AA, 0x26AB,
    0x26B0, 0x26B1,
    0x26BD, 0x26BE,
    0x26C4, 0x26C5, 0x26C8,
    0x26CE, 0x26CF, 0x26D1, 0x26D3, 0x26D4,
    0x26E9, 0x26EA,
    *range(0x26F0, 0x26F6),
    0x26F7, 0x26F8, 0x26F9, 0x26FA, 0x26FD,
    0x2702, 0x2705,
    *range(0x2708, 0x2710),
    0x2712, 0x2714, 0x2716, 0x271D, 0x2721, 0x2728,
    0x2733, 0x2734, 0x2744, 0x2747,
    0x274C, 0x274E,
    0x2753, 0x2754, 0x2755, 0x2757,
    0x2763, 0x2764,
    0x2795, 0x2796, 0x2797,
    0x27A1, 0x27B0, 0x27BF,
    0x2934, 0x2935,
    *range(0x2B05, 0x2B08),
    0x2B1B, 0x2B1C, 0x2B50, 0x2B55,
    0x3030, 0x303D, 0x3297, 0x3299,
    # ➤ (seta do prompt) — no Windows Terminal conta como 1; deixa como 1
}

# Seletores de variação e combinadores invisíveis
_ZERO_WIDTH = {
    *range(0xFE00, 0xFE10),   # variation selectors
    *range(0xE0100, 0xE01F0), # variation selectors supplement
    0x200B, 0x200C, 0x200D,   # zero-width space/non-joiner/joiner
    0x200E, 0x200F,            # LRM / RLM
    0xFEFF,                    # BOM / zero-width no-break space
}

def char_width(ch):
    cp = ord(ch)
    if cp in _ZERO_WIDTH:
        return 0
    if cp in _WIDE_EXTRA:
        return 2
    # Plano suplementar (emojis, símbolos, etc.)
    if cp >= 0x10000:
        return 2
    eaw = unicodedata.east_asian_width(ch)
    if eaw in ('W', 'F'):
        return 2
    return 1

def visible_width(text):
    """Calcula a largura visual ignorando ANSI escapes."""
    stripped = re.sub(r'\033\[[0-9;]*m', '', text)
    return sum(char_width(ch) for ch in stripped)

def rpad(text, total_width):
    """Preenche com espaços à direita até total_width colunas visíveis."""
    return text + " " * max(total_width - visible_width(text), 0)

# ── Box helpers ───────────────────────────────────────────────────────────────

def bline(color, content):
    print(f"  {color}{BOLD}║{RESET}{content}{color}{BOLD}║{RESET}")

def htop(color): print(f"  {color}{BOLD}╔{'═' * W}╗{RESET}")
def hmid(color): print(f"  {color}{BOLD}╠{'═' * W}╣{RESET}")
def hbot(color): print(f"  {color}{BOLD}╚{'═' * W}╝{RESET}")

# ── Telas ─────────────────────────────────────────────────────────────────────

def enable_ansi_windows():
    if platform.system() == "Windows":
        os.system("color")
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass

def clear():
    os.system("cls" if platform.system() == "Windows" else "clear")

def set_title(title):
    if platform.system() == "Windows":
        os.system(f"title {title}")

def print_header(icon="[*]"):
    inner = f"  {icon}  {WHITE}{BOLD}SHUTDOWN PRO  --  DESLIGAMENTO AUTOMATICO  {icon}{RESET}"
    print()
    htop(RED)
    bline(RED, rpad(inner, W))
    hbot(RED)
    print()

def print_menu():
    titulo = f"   {YELLOW}[>] Escolha quando desligar o PC:{RESET}"
    print()
    htop(CYAN)
    bline(CYAN, rpad(titulo, W))
    hmid(CYAN)

    opcoes = [
        ("1", "[1h]",  "1 hora"),
        ("2", "[2h]",  "2 horas"),
        ("3", "[4h]",  "4 horas"),
        ("4", "[6h]",  "6 horas"),
        ("5", "[8h]",  "8 horas"),
        ("6", "[10h]", "10 horas"),
        ("7", "[12h]", "12 horas"),
    ]

    for num, badge, label in opcoes:
        row = f"   {GREEN}{BOLD}[{num}]{RESET}  {CYAN}{badge}{RESET}  {WHITE}{label}{RESET}"
        bline(CYAN, rpad(row, W))

    hmid(CYAN)
    cancel_row = f"   {RED}{BOLD}[8]{RESET}  {RED}[X]{RESET}  {WHITE}Cancelar todos os agendamentos{RESET}"
    bline(CYAN, rpad(cancel_row, W))
    sair_row   = f"   {DIM}[9]{RESET}  {DIM}[>>]{RESET}  {DIM}Sair{RESET}"
    bline(CYAN, rpad(sair_row, W))
    hbot(CYAN)
    print()

def print_status_bar():
    now      = time.strftime("%H:%M:%S")
    sys_name = platform.node()
    print(f"  {DIM}[PC] {sys_name}   [T] {now}{RESET}")
    print()

def animate_header():
    frames = ["[*]", "[!]", "[*]", "[!]", "[*]"]
    for f in frames:
        clear()
        print_header(f)
        time.sleep(0.12)

def countdown():
    print(f"\n  {DIM}Voltando ao menu em 3 segundos", end="", flush=True)
    for _ in range(3):
        time.sleep(1)
        print(".", end="", flush=True)
    print(RESET)

def confirm(message):
    print(f"\n  {YELLOW}{BOLD}[!]  {message}{RESET}")
    print(f"  {DIM}Pressione {BOLD}ENTER{RESET}{DIM} para confirmar ou {BOLD}Ctrl+C{RESET}{DIM} para cancelar...{RESET}")
    try:
        input()
        return True
    except KeyboardInterrupt:
        return False

def schedule_shutdown(seconds, label):
    if not confirm(f"O PC sera desligado em {label}. Confirmar?"):
        print(f"\n  {YELLOW}[!] Acao cancelada.{RESET}\n")
        time.sleep(1.5)
        return

    msg = f"O PC sera desligado em {label}."
    if platform.system() == "Windows":
        subprocess.run(["shutdown", "-a"], capture_output=True)
        subprocess.run(["shutdown", "-s", "-t", str(seconds), "-f", "-c", msg], capture_output=True)
    else:
        subprocess.run(["sudo", "shutdown", "-c"], capture_output=True)
        at_t = time.strftime("%H:%M", time.localtime(int(time.time()) + seconds))
        subprocess.run(f'echo "sudo shutdown -h now" | at {at_t}', shell=True, capture_output=True)

    clear()
    print()
    htop(GREEN)
    bline(GREEN, rpad(f"  [OK]  {WHITE}{BOLD}DESLIGAMENTO AGENDADO COM SUCESSO!{RESET}", W))
    hbot(GREEN)
    print(f"\n  {WHITE}  [T] PC sera desligado em: {YELLOW}{BOLD}{label}{RESET}\n")
    countdown()

def cancel_shutdown():
    if platform.system() == "Windows":
        subprocess.run(["shutdown", "-a"], capture_output=True)
    else:
        subprocess.run(["sudo", "shutdown", "-c"], capture_output=True)

    clear()
    print()
    htop(RED)
    bline(RED, rpad(f"  [X]  {WHITE}{BOLD}TODOS OS AGENDAMENTOS FORAM CANCELADOS!{RESET}", W))
    hbot(RED)
    print(f"\n  {WHITE}  Desligue o PC manualmente quando quiser.{RESET}\n")
    countdown()

def show_goodbye():
    clear()
    print()
    htop(MAGENTA)
    bline(MAGENTA, rpad(f"  [>>]  {WHITE}{BOLD}Ate logo! Shutdown Pro encerrado.{RESET}", W))
    hbot(MAGENTA)
    print()
    time.sleep(1)

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    enable_ansi_windows()
    set_title("SHUTDOWN PRO - Desligamento Automatico")

    opcoes_map = {
        "1": (3600,  "1 hora"),
        "2": (7200,  "2 horas"),
        "3": (14400, "4 horas"),
        "4": (21600, "6 horas"),
        "5": (28800, "8 horas"),
        "6": (36000, "10 horas"),
        "7": (43200, "12 horas"),
    }

    animate_header()

    while True:
        clear()
        print_header()
        print_menu()
        print_status_bar()

        try:
            choice = input(f"  {BOLD}{CYAN}>>  Digite a opcao:{RESET} ").strip()
        except KeyboardInterrupt:
            show_goodbye()
            sys.exit(0)

        if choice in opcoes_map:
            schedule_shutdown(*opcoes_map[choice])
        elif choice == "8":
            cancel_shutdown()
        elif choice == "9":
            show_goodbye()
            sys.exit(0)
        else:
            print(f"\n  {RED}[!] Opcao invalida! Tente novamente.{RESET}")
            time.sleep(1.2)

if __name__ == "__main__":
    main()
