#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import uuid
from pathlib import Path

import requests


POSTS_DIR = Path("posts")
OUTPUT_DIR = Path("posts_reescritos")
IMAGES_DIR = OUTPUT_DIR / "images"

OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "qwen3:8b"

COMFYUI_URL = "http://127.0.0.1:8188"
COMFYUI_WORKFLOW_PATH = Path("comfyui_workflow_api.json")
COMFYUI_POSITIVE_PROMPT_NODE = "6"
COMFYUI_OUTPUT_NODE = "9"

UNAVAILABLE_MARKER = "TRANSCRIÇÃO NÃO DISPONÍVEL"

SYSTEM_PROMPT = """Você é um editor de conteúdo. Recebe a transcrição bruta, gerada por \
legenda automática do YouTube, sem pontuação correta e sem divisão de parágrafos, da fala \
de um narrador comentando notícias e dando opiniões pessoais, às vezes sobre temas sociais \
sensíveis. Sua tarefa:

1. Identificar os assuntos/temas distintos abordados, na ordem em que aparecem.
2. A transcrição automática comete erros por semelhança sonora, produzindo trechos sem \
sentido (exemplo real: "elas pinto 17" no lugar de "elas pintam o sete", uma expressão \
comum). Sempre que um trecho não fizer sentido nesse contexto e você conseguir inferir com \
confiança, pelo som ou pelo contexto, qual era a palavra ou expressão real, corrija. Se um \
nome próprio, termo técnico ou referência parecer mal transcrito mas você NÃO tiver \
confiança suficiente para corrigir, mantenha o texto como foi ouvido, mas envolva esse \
trecho exatamente assim: {{texto como foi ouvido}}. Não use essa marcação para nada além de \
termos duvidosos.
3. Reescrever o texto em português correto, com pontuação e parágrafos, dividido em seções \
com subtítulos (##), uma por tema.
4. Preservar integralmente as opiniões, argumentos e posicionamentos do narrador, sem \
suavizar, remover ou censurar nenhum conteúdo por ser polêmico. Não insira ressalvas, \
avisos ou disclaimers que não estavam no texto original.
5. Se aparecerem marcadores como "VOLTANDO AQUI" ou expressões parecidas indicando que o \
narrador retomou a leitura de uma notícia após um comentário, trate isso como sinal de \
início de um novo bloco temático.
6. Escrever também uma frase curta, em inglês, descrevendo uma imagem abstrata/simbólica \
que represente o tema central do texto, sem retratar pessoas reais, adequada para servir \
de thumbnail de um blog.

Responda apenas em JSON, no formato:
{"post": "<texto reescrito em markdown com subtítulos ##>", "image_prompt": "<frase em inglês>"}
"""

CAPTION_HEADER_PATTERN = re.compile(r"^(Kind:|Language:)", re.IGNORECASE)


def strip_caption_header(transcript: str) -> str:
    lines = transcript.split("\n")
    while lines and CAPTION_HEADER_PATTERN.match(lines[0].strip()):
        lines.pop(0)
    return "\n".join(lines).strip()


def split_post(content: str) -> tuple[str, str, str] | None:
    parts = content.split("---", 2)
    if len(parts) < 3:
        return None

    front_matter = parts[1]
    body = parts[2]

    marker_idx = body.find("## Vídeo")
    if marker_idx == -1:
        return None

    transcript = strip_caption_header(body[:marker_idx].strip())
    video_block = body[marker_idx:].strip()

    return front_matter, transcript, video_block


def call_ollama(transcript: str) -> dict:
    payload = {
        "model": OLLAMA_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": transcript},
        ],
        "format": "json",
        "think": False,
        "stream": False,
        "options": {"temperature": 0.3},
    }

    response = requests.post(OLLAMA_URL, json=payload, timeout=600)
    response.raise_for_status()
    content = response.json()["message"]["content"]
    return json.loads(content)


def load_comfyui_workflow() -> dict:
    with open(COMFYUI_WORKFLOW_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def generate_thumbnail(image_prompt: str, output_path: Path) -> bool:
    if not COMFYUI_WORKFLOW_PATH.exists():
        print(f"    Aviso: {COMFYUI_WORKFLOW_PATH} não encontrado, pulando thumbnail.")
        return False

    workflow = load_comfyui_workflow()
    workflow[COMFYUI_POSITIVE_PROMPT_NODE]["inputs"]["text"] = image_prompt

    client_id = str(uuid.uuid4())
    submit = requests.post(
        f"{COMFYUI_URL}/prompt",
        json={"prompt": workflow, "client_id": client_id},
        timeout=60,
    )
    submit.raise_for_status()
    prompt_id = submit.json()["prompt_id"]

    for _ in range(180):
        time.sleep(2)
        history = requests.get(f"{COMFYUI_URL}/history/{prompt_id}", timeout=30)
        history.raise_for_status()
        data = history.json()

        if prompt_id not in data:
            continue

        outputs = data[prompt_id].get("outputs", {})
        node_output = outputs.get(COMFYUI_OUTPUT_NODE)

        if not node_output or "images" not in node_output:
            continue

        image_info = node_output["images"][0]
        image_response = requests.get(
            f"{COMFYUI_URL}/view",
            params={
                "filename": image_info["filename"],
                "subfolder": image_info.get("subfolder", ""),
                "type": image_info.get("type", "output"),
            },
            timeout=60,
        )
        image_response.raise_for_status()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(image_response.content)
        return True

    print("    Aviso: timeout esperando a imagem do ComfyUI.")
    return False


def build_output(front_matter: str, cover_path: str, rewritten_post: str, video_block: str) -> str:
    front_matter = front_matter.rstrip("\n")
    front_matter += f'\ncover: "{cover_path}"\n'
    return f"---{front_matter}---\n\n{rewritten_post.strip()}\n\n{video_block}\n"


def process_file(path: Path) -> str:
    content = path.read_text(encoding="utf-8")
    parsed = split_post(content)

    if parsed is None:
        return "erro_formato"

    front_matter, transcript, video_block = parsed

    if not transcript or UNAVAILABLE_MARKER in transcript:
        return "sem_transcricao"

    output_path = OUTPUT_DIR / path.name
    if output_path.exists():
        return "pulado"

    print("    Chamando o modelo (pode levar alguns minutos)...")
    start = time.monotonic()
    result = call_ollama(transcript)
    elapsed = time.monotonic() - start
    print(f"    Modelo respondeu em {elapsed:.0f}s")

    rewritten_post = result["post"]
    image_prompt = result["image_prompt"]

    image_filename = f"{path.stem}.png"
    image_path = IMAGES_DIR / image_filename
    has_image = generate_thumbnail(image_prompt, image_path)
    cover_path = f"images/{image_filename}" if has_image else ""

    output = build_output(front_matter, cover_path, rewritten_post, video_block)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path.write_text(output, encoding="utf-8")

    return "ok"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=15)
    parser.add_argument("--all", action="store_true")
    args = parser.parse_args()

    files = sorted(POSTS_DIR.glob("*.md"))
    if not args.all:
        files = files[: args.limit]

    print("=" * 70)
    print("Reescrita de posts")
    print("=" * 70)
    print(f"Arquivos a processar: {len(files)}")
    print()

    counts = {"ok": 0, "pulado": 0, "sem_transcricao": 0, "erro_formato": 0, "erro": 0}

    for index, path in enumerate(files, start=1):
        print(f"[{index}/{len(files)}] {path.name}")
        try:
            status = process_file(path)
            counts[status] = counts.get(status, 0) + 1
            print(f"    {status}")
        except KeyboardInterrupt:
            print("\nInterrompido pelo usuário.")
            break
        except Exception as exc:
            counts["erro"] += 1
            print(f"    ERRO: {type(exc).__name__}: {exc}")

    print()
    print("=" * 70)
    print("FINALIZADO")
    print("=" * 70)
    for status, count in counts.items():
        print(f"{status}: {count}")
    print(f"Arquivos em: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
